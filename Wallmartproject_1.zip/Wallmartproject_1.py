#!/usr/bin/env python
# coding: utf-8

# In[3]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.statespace.sarimax import SARIMAX,SARIMAXResults
import warnings
warnings.filterwarnings("ignore")


# In[4]:


#read the dataset
df=pd.read_csv("Walmart (1).csv")
df=df[df["Holiday_Flag"]!="Holiday_Flag"]
df.shape


# In[5]:


df.head(5)


# In[6]:


df.Store.nunique()


# In[7]:


df.info()


# In[12]:


df.isnull().sum()


# In[13]:


df.duplicated().sum()


# In[14]:


df['Store']=df['Store'].astype('int')
df['Holiday_Flag']=df['Holiday_Flag'].astype('int')
df['Date']=df['Date'].astype('datetime64')
df['Weekly_Sales']=df['Weekly_Sales'].astype('float')
df['Temperature']=df['Temperature'].astype('float')
df['Fuel_Price']=df['Fuel_Price'].astype('float')
df['CPI']=df['CPI'].astype('float')
df['Unemployment']=df['Unemployment'].astype('float')


# In[15]:


df['Year'] = df['Date'].dt.year
df['Month'] = df['Date'].dt.month
df['Week'] = df['Date'].dt.week


# In[16]:


df.info()


# In[17]:


df.describe()


# In[18]:


plt.figure(figsize=(12,8))
sns.heatmap(df.corr(),annot=True)


# In[19]:


df.to_csv('clean_data.csv',index=False)


# In[20]:


new_data = df.groupby('Date')['Weekly_Sales'].sum().reset_index()
new_data = new_data.set_index('Date')
new_data.index.name='Date'


# In[21]:


from statsmodels.tsa.stattools import adfuller
def ad_test(dataset):
     dftest = adfuller(dataset, autolag = 'AIC')
     print("1. ADF : ",dftest[0])
     print("2. P-Value : ", dftest[1])
     print("3. Num Of Lags : ", dftest[2])
     print("4. Num Of Observations Used For ADF Regression:",dftest[3])
     print("5. Critical Values :")
     for key, val in dftest[4].items():
         print("\t",key, ": ", val)
ad_test(new_data['Weekly_Sales'])


# In[22]:


from statsmodels.tsa.stattools import kpss
def kpss_test(dataset):
    kpsstest = kpss(dataset, regression ='c')
    print("1. ADF : ",kpsstest[0])
    print("2. P-Value : ", kpsstest[1])
    print("3. Num Of Lags : ", kpsstest[2])
    print("4. Num Of Observations Used For kpss Regression:",kpsstest[3])
    
kpss_test(new_data["Weekly_Sales"].values)


# In[23]:


new_data.Weekly_Sales.plot(figsize=(15,5))


# In[24]:


rolmean = new_data['Weekly_Sales'].rolling(12).mean()
rolstd = new_data['Weekly_Sales'].rolling(12).std()
 #Plot rolling statistics:
orig = plt.plot(new_data['Weekly_Sales'], color='blue',label='Original')
mean = plt.plot(rolmean, color='red', label='Rolling Mean')
std = plt.plot(rolstd, color='black', label = 'Rolling Std')
plt.legend(loc='best')
plt.title('Rolling Mean & Standard Deviation')
plt.show(block=False)


# In[25]:


data=np.log(new_data)
data.index = pd.DatetimeIndex(data.index.values,
                               freq=data.index.inferred_freq)


# In[26]:


data=pd.DataFrame(data - data.shift())
plt.plot(data)


# In[27]:


data=data.dropna()


# In[28]:


rolmean = data['Weekly_Sales'].rolling(12).mean()
rolstd = data['Weekly_Sales'].rolling(12).std()
 #Plot rolling statistics:
orig = plt.plot(data['Weekly_Sales'], color='blue',label='Original')
mean = plt.plot(rolmean, color='red', label='Rolling Mean')
std = plt.plot(rolstd, color='black', label = 'Rolling Std')
plt.legend(loc='best')
plt.title('Rolling Mean & Standard Deviation')
plt.show(block=False)


# In[29]:


from statsmodels.tsa.seasonal import seasonal_decompose
decompose_result=seasonal_decompose(data['Weekly_Sales'],model='additive', extrapolate_trend='freq', period=1)
decompose_result.plot()
plt.show()


# In[30]:


from statsmodels.tsa.stattools import acf, pacf
lag_acf = acf(data, nlags=20)
lag_pacf = pacf(data, nlags=20, method='ols')

plt.figure(figsize=(16, 7))
#Plot ACF: 
plt.subplot(121) 
plt.plot(lag_acf, marker="o")
plt.axhline(y=0,linestyle='--',color='gray')
plt.axhline(y=-1.96/np.sqrt(len(data)),linestyle='--',color='gray')
plt.axhline(y=1.96/np.sqrt(len(data)),linestyle='--',color='gray')
plt.title('Autocorrelation Function')


#Plot PACF:
plt.subplot(122)
plt.plot(lag_pacf, marker="o")
plt.axhline(y=0,linestyle='--',color='gray')
plt.axhline(y=-1.96/np.sqrt(len(data)),linestyle='--',color='gray')
plt.axhline(y=1.96/np.sqrt(len(data)),linestyle='--',color='gray')
plt.title('Partial Autocorrelation Function')
plt.tight_layout()


# In[33]:


model1 = ARIMA(data, order=(5,2,2))  
model1_fit = model1.fit()  
plt.plot(data)
plt.plot(model1_fit.fittedvalues, color='red')


# In[34]:


forecast1 = model1_fit.predict(start=0,end=141)
forecast1


# In[35]:


def mean_absolute_error(y_true, y_pred):
    return np.mean(np.abs(y_true - y_pred))

def mean_squared_error(y_true, y_pred):
    return np.mean((y_true - y_pred)**2)

def root_mean_squared_error(y_true, y_pred):
    return np.sqrt(mean_squared_error(y_true, y_pred))


# In[36]:


y_true=data['Weekly_Sales']
y_pred=model1_fit.fittedvalues
mae = mean_absolute_error(y_true, y_pred)
print("MAE: ", mae)

mse = mean_squared_error(y_true, y_pred)
print("MSE: ", mse)

rmse = root_mean_squared_error(y_true, y_pred)
print("RMSE: ", rmse)


# In[37]:


import joblib
from statsmodels.tsa.statespace.sarimax import SARIMAX,SARIMAXResults
model2= SARIMAX(data['Weekly_Sales'],order=(4,0,1),seasonal_order=(1,1,1,12),enforce_stationarity=False,enforce_invertibility=False)
model2_fit=model2.fit()
filename = 'sarimax_model.sav'
joblib.dump(model2,filename)
model2_fit.summary()


# In[38]:


model2_fit.plot_diagnostics(figsize=(16, 8))
plt.show()


# In[39]:


results=model2_fit
start_forecast = 50
pred = results.get_prediction(start=start_forecast, dynamic=False)
pred_ci = pred.conf_int()

ax = data['Weekly_Sales'].plot(label='observed')
pred.predicted_mean.plot(ax=ax, label='Predictions', alpha=.7)

ax.fill_between(pred_ci.index,
                pred_ci.iloc[:, 0],
                pred_ci.iloc[:, 1], color='k', alpha=.2)

ax.set_xlabel('Date')
ax.set_ylabel('Weekly Sales')
plt.legend()

plt.show()


# In[40]:


x=pd.DataFrame({'forecast':model2_fit.predict(start = 142, end = 191, dynamic= True)})
x.index=pd.date_range('2012-11-05', periods=50, freq='W-FRI')
x=pd.concat([data,x])


# In[41]:


#predictions
ax=x.forecast.plot(label='Predictions', alpha=.7)
ax.set_xlabel('Date')
ax.set_ylabel('Weekly Sales')
plt.legend()
plt.show()


# In[42]:


ax = data['Weekly_Sales'].plot(label='Observed')
x.forecast.plot(ax=ax, label='Predictions', alpha=.7)
ax.set_xlabel('Date')
ax.set_ylabel('Weekly Sales')
plt.legend()
plt.show()


# In[43]:


#evaluation
y_true=data['Weekly_Sales']
y_pred=model2_fit.fittedvalues
mae = mean_absolute_error(y_true, y_pred)
print("MAE: ", mae)

mse = mean_squared_error(y_true, y_pred)
print("MSE: ", mse)

rmse = root_mean_squared_error(y_true, y_pred)
print("RMSE: ", rmse)


# In[44]:


def forecast(df,store_num):
    store_data=df[df['Store']==store_num]
    store_data.index=pd.to_datetime(store_data['Date'])
    store_data.drop(['Date','Store','Holiday_Flag','Temperature','Fuel_Price','CPI',"Unemployment"], axis = 1, inplace = True)
    model=SARIMAX(store_data['Weekly_Sales'],order=(4,0,1),seasonal_order=(1,1,1,12),enforce_stationarity=False,enforce_invertibility=False)
    model_fit=model.fit()
    forecast_df=pd.DataFrame(model_fit.forecast(steps=24))
    rng = pd.date_range(start='2012-12-10',end='2013-03-10', periods=24)
    forecast_df.loc[:,"Date"]=rng
    forecast_df.index=pd.to_datetime(forecast_df['Date'])
    forecast_df.drop(['Date'], axis = 1, inplace = True)
    forecast_df.rename(columns={'predicted_mean':'Weekly_Sales'},inplace=True)
    combined_df = pd.concat([store_data, forecast_df])
    combined_df["store_num"]=store_num
    combined_df.reset_index(inplace=True)
    return combined_df


# In[45]:


df_allstores_forecast=pd.DataFrame(columns=["Date","Weekly_Sales","store_num"])
df_allstores_forecast


# In[46]:


for store_num in df.Store.unique():
    df_allstores_forecast=pd.concat([df_allstores_forecast,forecast(df,store_num)],axis=0)
df_allstores_forecast=df_allstores_forecast.sort_values(by=['store_num','Date'])
import plotly.express as px
import plotly.graph_objects as go
fig=px.line(df_allstores_forecast,x='Date',y='Weekly_Sales',color='store_num')
fig.show()
fig.write_html("temp.html",auto_open=True)


# In[49]:


#Average Monthly Sales
import matplotlib.pyplot as plt
import seaborn as sns
plt.figure(figsize=(14,8))
sns.barplot(x='Month',y='Weekly_Sales',hue='Holiday_Flag',data=df)
plt.ylabel('Sales',fontsize=14)
plt.xlabel('Months',fontsize=14)
plt.title('Average Monthly Sales',fontsize=16)
plt.savefig('avg_monthly_sales.png')
plt.grid()


# In[50]:


#Average Weekly Sales Store wise

plt.figure(figsize=(20,8))
sns.barplot(x='Store',y='Weekly_Sales',data=df)
plt.grid()
plt.title('Average Sales per Store', fontsize=18)
plt.ylabel('Sales', fontsize=16)
plt.xlabel('Store', fontsize=16)
plt.savefig('avg_sales_store.png')
plt.show()


# In[51]:


sns.boxplot(y="CPI",x="Year",data=df)


# In[52]:


plt.figure(figsize=(12,8))
sns.scatterplot(y="CPI",x="Weekly_Sales",data=df,hue='Year')


# In[53]:


plt.figure(figsize=(12,8))
sns.scatterplot(x="Unemployment",y="Weekly_Sales",data=df,hue='Year')


# In[54]:


fig.show()


# In[ ]:




